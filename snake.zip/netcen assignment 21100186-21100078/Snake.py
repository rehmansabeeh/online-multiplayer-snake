import curses
import random
from   curses import KEY_RIGHT, KEY_LEFT, KEY_UP, KEY_DOWN	
from random import  randint


def moveit(tempprevkey, screen, snake):

	tempevent = screen.getch()
	key = tempprevkey if tempevent == -1 else tempevent
	if key == tempprevkey:
		awi = 1
	else:	
		if key not in [KEY_RIGHT, KEY_LEFT, KEY_UP, KEY_DOWN]:
			key=tempprevkey
		if key==KEY_RIGHT and tempprevkey==KEY_LEFT:
			key=tempprevkey
		if key==KEY_LEFT and tempprevkey==KEY_RIGHT:	#eats itself
			key=tempprevkey
		if key==KEY_UP and tempprevkey==KEY_DOWN:
			key=tempprevkey
		if key==KEY_DOWN and tempprevkey==KEY_UP:
			key=tempprevkey
	# if key == ord(' '):
	# 	key=-1
	# 	while key != ord(' '):
	# 		key = screen.getch()
	# 	key=tempprevkey
	# 	return True	

	



	snake.pop()
	snake.insert(0, [snake[0][0]+ (key==KEY_DOWN and 1) + (key==KEY_UP and -1), snake[0][1]+ (key == KEY_LEFT and -1)+ (key == KEY_RIGHT and 1) ])	
	return key

def Print(snakes, screen):
	for snake in snakes:
		for i in snake:	
			screen.addch(i[0],i[1], '-') #apna different print ho

def collisions(snakes, snake):

	if snake == []: return True

	if snake[0][0]<1: 
		return True  #upar
	if snake[0][1]<1: 
		return True
	if snake[0][0]>18: 
		return True
	if snake[0][1]>58: 
		return True
	if snake[0] in snake[1:] : return True

	for i in range(0,len(snakes)):
		if snakes[i] != []: 
			if snakes[i] != snake and snakes[i][0] in snake[0:] :return True
	return False	
