import socket
import ast
import random
import sys

a=sys.argv


host = ''
port = int(a[2])
numplayers = int(a[3])
positions = []
players = []
sneklen = 6
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


#==============Functions=================

def RandomPos():
	for i in range(0, numplayers):
		y = i + 2
		x = random.randint(7,39)
		snek = [[y,x]]
		for j in range(1,sneklen):
			snek.append([y,x-j])

		positions.append(snek)


	# heads = set(())
	# while(len(heads) < numplayers):
	# 	y = random.randint(7,19)
	# 	x = random.randint(7,39)
	# 	heads.add([y,x])
	
	# for head in heads:
	# 	snek = [[head[0],head[1]]]
	# 	for i in range(1,sneklen):
	# 		snek.append([head[0],head[1]-i])

	# 	positions.append(snek)

def Chalo():

	numalive = numplayers
	for snek in positions:
		if snek == []:
			numalive = numalive - 1
	while numalive > 1 :
		numalive = numplayers
		for snek in positions:
			if snek == []:
				numalive = numalive - 1

		positions.clear()
		for player in players:
			temppos = player.recv(1024).decode()
			positions.append(ast.literal_eval(temppos))

		for player in players:
			print("pos:", positions)
			if numalive > 1:
				player.send(str(positions).encode())
			else:
				player.send("Game Over!".encode())
		

#========================================


try:
    s.bind((host, port))
except socket.error as e:
    print(str(e))

s.listen(numplayers)
print('Waiting for connections')



while len(players) < numplayers:
	conn, addr = s.accept()
	players.append(conn)
	print('connected to: '+addr[0]+':'+str(addr[1]))

RandomPos()

for i in range(0,numplayers):
	temp = {"you": positions[i], "everyone":positions}

	players[i].send(str(temp).encode())


Chalo()