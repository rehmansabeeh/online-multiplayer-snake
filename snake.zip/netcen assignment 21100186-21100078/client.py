import socket
import Snake
import ast
import curses
from  curses import KEY_RIGHT, KEY_LEFT, KEY_UP, KEY_DOWN
import sys

a=sys.argv


host = a[1]
port = int(a[2])
score=0
key = KEY_RIGHT


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ('created')
try:
    s.connect((host, port))
    print("connected")
except socket.error as e:
    print(str(e))

data = s.recv(1024).decode()
temp = ast.literal_eval(data)

snake = temp["you"]
pos = temp["everyone"]


def games(screen):
    global score
    global snake
    global pos
    screen = curses.newwin(30,100,0,0)

    screen.keypad(1)
    screen.nodelay(1)
    key = KEY_RIGHT
    
    while key != 27:
        screen.border()
        screen.addstr(0,2, 'total score :' + str(score) + ' ')
        screen.addstr(0,57, 'SNAKE')
        screen.timeout(150)

        Snake.Print(pos, screen)

        tempprevkey=key

        if Snake.collisions(pos, snake):
        	snake = []
        	tempevent = screen.getch()

        else:
        	key = Snake.moveit(tempprevkey, screen, snake)

        s.send(str(snake).encode())

        datapos = s.recv(1024).decode()   # "[[11,10],[11,9],[11,8]]" required: [[11,10],[11,9],[11,8]]
        if datapos == "Game Over!":
        	screen.nodelay(0)
        	screen.addstr(5,5, datapos)
        	key = screen.getch()
        	
        	break

        pos = ast.literal_eval(datapos)
        
            
        screen.clear()
        screen.refresh()
        


curses.wrapper(games)
s.close()
